package com.example.imageupload;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class ShowImageActivity extends AppCompatActivity {
    private DatabaseHelper objectDatabaseHelper;
    private RecyclerView objectRecycleView;

   private RVAdapter objectRVAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_image);
        try{
            objectRecycleView=findViewById(R.id.imageRV);
            objectDatabaseHelper=new DatabaseHelper(this);
        }
        catch (Exception e){
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

    public void getData(View view)
    {
        try {

            objectRVAdapter=new RVAdapter(objectDatabaseHelper.getAllImagesData());
            objectRecycleView.setHasFixedSize(true);

            objectRecycleView.setLayoutManager(new LinearLayoutManager(this));
            objectRecycleView.setAdapter(objectRVAdapter);

        }
        catch (Exception e){
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }
}